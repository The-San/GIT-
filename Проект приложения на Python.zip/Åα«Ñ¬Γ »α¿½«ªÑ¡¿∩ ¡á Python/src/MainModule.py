import tkinter as tk
from tkinter import filedialog, messagebox
from SampleModule import convert_to_black_and_white, move_image


class ImageUtilityApp:

    def __init__(self, root):
        self.root = root
        self.root.title("Утилита работы с изображениями")
        self.image_path = None

        # UI Elements
        self.label = tk.Label(root, text="Выбранное изображение: ")
        self.label.pack()

        self.load_button = tk.Button(
            root, text="Загрузить изображение", command=self.load_image
        )
        self.load_button.pack()

        self.bw_button = tk.Button(
            root, text="Изменить на черно-белое", command=self.convert_bw
        )
        self.bw_button.pack()

        self.move_button = tk.Button(
            root, text="Переместить изображение", command=self.move_image_dialog
        )
        self.move_button.pack()

        self.info_label = tk.Label(root, text="Блок информации о действиях")
        self.info_label.pack()

    def load_image(self):
        self.image_path = filedialog.askopenfilename(
            filetypes=[("Image files", "*.jpg;*.jpeg;*.png;*.bmp")]
        )
        self.label.config(text=f"Выбранное изображение: {self.image_path}")

    def convert_bw(self):
        if self.image_path:
            new_image = convert_to_black_and_white(self.image_path)
            self.info_label.config(text=f"Изображение конвертировано: {new_image}")
            messagebox.showinfo(
                "Готово", "Изображение успешно конвертировано в черно-белое."
            )
        else:
            messagebox.showwarning("Ошибка", "Пожалуйста, выберите изображение.")

    def move_image_dialog(self):
        if self.image_path:
            target_directory = filedialog.askdirectory()
            if target_directory:
                new_path = move_image(self.image_path, target_directory)
                self.info_label.config(text=f"Изображение перемещено в: {new_path}")
                messagebox.showinfo("Готово", "Изображение успешно перемещено.")
        else:
            messagebox.showwarning("Ошибка", "Пожалуйста, выберите изображение.")


if __name__ == "__main__":
    root = tk.Tk()
    app = ImageUtilityApp(root)
    root.mainloop()
