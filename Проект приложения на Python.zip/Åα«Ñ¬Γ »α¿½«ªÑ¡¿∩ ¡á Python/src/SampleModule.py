from PIL import Image
import os


def convert_to_black_and_white(image_path):
    """Конвертирует изображение в черно-белое."""
    img = Image.open(image_path)
    bw = img.convert("L")
    new_file_path = os.path.splitext(image_path)[0] + "_bw.png"
    bw.save(new_file_path)
    return new_file_path


def move_image(image_path, target_directory):
    """Перемещает изображение в другую папку."""
    if not os.path.exists(target_directory):
        os.makedirs(target_directory)
    image_name = os.path.basename(image_path)
    new_path = os.path.join(target_directory, image_name)
    os.rename(image_path, new_path)
    return new_path
